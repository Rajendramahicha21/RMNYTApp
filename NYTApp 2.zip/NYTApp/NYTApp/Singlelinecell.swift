//
//  Singlelinecell.swift

//  Created by Rajendra Kumar on 07/08/19.



import UIKit
 class  Singlelinecell: UITableViewCell {

    @IBOutlet var detailsLabel: UILabel!
    @IBOutlet var nameLabel: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}
