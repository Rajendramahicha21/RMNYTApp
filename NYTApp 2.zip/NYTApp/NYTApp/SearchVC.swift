//
//  ViewedList.swift


//  Created by Rajendra Kumar on 07/08/19.


var strSearchText = NSString()


import UIKit
import Alamofire



class SearchVC: UIViewController,UIAlertViewDelegate{
    

    @IBOutlet weak var tftSearch: UITextField!
    
    @IBOutlet weak var btnSearch: UIButton!
    
    var arrData = NSArray()
   
   
   
   
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
            
           self.title = "Search"
        
      
        
    }
   
    @IBAction func searchButtonClicked(_ sender: Any) {
        
        if ((tftSearch.text? .isEmpty)!) {
            print("text empty.....")
            
            let Alert: UIAlertView = UIAlertView(title: "NYT", message: "Please enter articles...",
                                                        delegate: self, cancelButtonTitle: "OK")
               Alert.show()
        }
        else{
            
            strIsFrom = "search"
            tftSearch.text = ""
            let vc :ViewedList  = ViewedList(nibName: "ViewedList", bundle: nil)
            self.navigationController?.pushViewController(vc, animated: true)
        }
        
       
        
    }
   
    
  
    
 
 }

    

