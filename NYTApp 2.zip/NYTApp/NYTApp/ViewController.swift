//
//  ViewController.swift
//  NYTApp
//
//  Created by Rajendra Kumar on 07/08/19.



var strIsFrom = String()


import UIKit
import Alamofire

class ViewController: UIViewController, UITableViewDataSource, UITableViewDelegate {

    @IBOutlet weak var tblView: UITableView!
    var arrData = NSArray()
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.title = "NYT"
        
       
        tblView.tableFooterView = UIView()
        tblView.delegate = self
        tblView.dataSource = self
        
        tblView.bounces = false
        tblView.isScrollEnabled = false
     
    
        tblView.register(UINib(nibName: "SignoutCell", bundle: nil), forCellReuseIdentifier: "SignoutCell")
    }
    // MARK: - Table view data source
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return 30
    }
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        
        if section == 0 {
            let headerView = UIView.init(frame: CGRect.init(x: 0, y: 0, width: tableView.frame.width, height: 30))
            
            headerView.backgroundColor = UIColor.gray
            
            let label = UILabel()
            label.frame = CGRect.init(x: 5, y: 5, width: headerView.frame.width-10, height: headerView.frame.height-10)
            label.text = "Search"
            label.textColor = UIColor.white
             headerView.addSubview(label)
             return headerView
        }
        else if section == 1{
            
            let headerView = UIView.init(frame: CGRect.init(x: 0, y: 0, width: tableView.frame.width, height: 30))
            
            let label = UILabel()
            headerView.backgroundColor = UIColor.gray
            label.frame = CGRect.init(x: 5, y: 5, width: headerView.frame.width-10, height: headerView.frame.height-10)
            label.text = "Popular"
            label.textColor = UIColor.white
            headerView.addSubview(label)
            return headerView
        }
        else{
           return nil
        }
 
    }
    
    func numberOfSections(in tableView: UITableView) -> Int
    {
        
        
        return 2
        
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int
    {
        
        if (section==0){
            return 1
        }
            
        else  if (section==1)
        {
            return 3
        }
        else{
            return 0
        }
        
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell
    {
        
        if indexPath.section == 0 {
            
           let cell = tableView.dequeueReusableCell(withIdentifier: "SignoutCell", for: indexPath as IndexPath) as! SignoutCell
            
            cell.selectionStyle = .none
            cell.textLabel?.textColor = UIColor.black
            cell.textLabel?.textAlignment = .left
            cell.selectionStyle = .none
            cell.accessoryType = .disclosureIndicator
            
         if indexPath.row == 0{
                cell.textLabel?.text = "Search Articles"
            }
            
            
            return cell
            
        }
        else if indexPath.section == 1 {
            
            let cell = tableView.dequeueReusableCell(withIdentifier: "SignoutCell", for: indexPath as IndexPath) as! SignoutCell
            
            // cell.textLabel?.text = "Update Profile"
            cell.textLabel?.textColor = UIColor.black
            cell.textLabel?.textAlignment = .left
            cell.selectionStyle = .none
            cell.accessoryType = .disclosureIndicator
            if indexPath.row == 0{
                cell.textLabel?.text = "Most Viewed"
            }
            else if indexPath.row == 1{
                cell.textLabel?.text = "Most Shared"
            }
            else{
                cell.textLabel?.text = "Most Emailed"
            }
           
            
            return cell
            
        }
        else{
            let cell = tableView.dequeueReusableCell(withIdentifier: "SignoutCell", for: indexPath as IndexPath) as! SignoutCell
          
            
            return cell
        }
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat
    {
        return 50
        
        
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath)
    {
        if indexPath.section == 0 {
            
            print("Click on search.....")
            
            let vc :SearchVC  = SearchVC(nibName: "SearchVC", bundle: nil)
            self.navigationController?.pushViewController(vc, animated: true)
            
        }
        else if indexPath.section == 1 {
            
            
            if indexPath.row == 0
            {
                strIsFrom = "mostviewed"
                let vc :ViewedList  = ViewedList(nibName: "ViewedList", bundle: nil)
                self.navigationController?.pushViewController(vc, animated: true)
            }
            else if indexPath.row == 1
            {
                strIsFrom = "mostshared"
                let vc :ViewedList  = ViewedList(nibName: "ViewedList", bundle: nil)
                self.navigationController?.pushViewController(vc, animated: true)
            }
            else
            {
                strIsFrom = "mostemailed"
                let vc :ViewedList  = ViewedList(nibName: "ViewedList", bundle: nil)
                self.navigationController?.pushViewController(vc, animated: true)
            }
            
           
            
        }
       
    }
   
    
    
    
}




