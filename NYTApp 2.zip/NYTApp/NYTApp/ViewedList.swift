//
//  ViewedList.swift


//  Created by Rajendra Kumar on 07/08/19.


var strempsite = String()
var stremprole = String()


import UIKit
import Alamofire



class ViewedList: UIViewController {
    

    
    @IBOutlet weak var tbl: UITableView!
    var arrData = NSArray()
    var dicSearchDetail = NSDictionary()
   
  
   
   
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        if strIsFrom == "mostviewed"{
            
            self.title = "Most Viewed"
            getMostPopularListApi()
        }
        else if strIsFrom == "mostshared"{
            
            self.title = "Most Shared"
            getMostSharedListApi()
        }
        else if strIsFrom == "search"{
            
            self.title = "Search Result"
            getSearchListApi()
        }
        else{
            self.title = "Most Emailed"
            getMostEmailedListApi()
        }
        
        tbl.register(UINib(nibName: "ViewedCell", bundle: nil), forCellReuseIdentifier: "ViewedCell")
        tbl.tableFooterView = UIView()
        tbl.delegate = self
        tbl.dataSource = self
        tbl.rowHeight = UITableView.automaticDimension
        tbl.estimatedRowHeight = UITableView.automaticDimension
        
        
    }
   
    func getMostPopularListApi() {
        
         ActivityIndicator.sharedInstance.setApActivityIndicator(condition: true)
        let todoEndpoint: String = "https://api.nytimes.com/svc/mostpopular/v2/emailed/7.json?api-key=eaTGTA4vEMAofzcISa9KeqxzPyBBEYPZ"
        Alamofire.request(todoEndpoint).responseJSON { (responseData) in
            if let json = responseData.result.value {
                let dic = json as! NSDictionary
                self.arrData = dic.object(forKey: "results") as! NSArray
               
                self.tbl.reloadData()
                 ActivityIndicator.sharedInstance.setApActivityIndicator(condition: false)
                guard responseData.result.error == nil else {
                    
                    print("error calling GET on /todos/1")
                    print(responseData.result.error!)
                    return
                }
            }}}
    
    
    func getMostSharedListApi() {
         ActivityIndicator.sharedInstance.setApActivityIndicator(condition: true)
        let todoEndpoint: String = "https://api.nytimes.com/svc/mostpopular/v2/shared/1/facebook.json?api-key=eaTGTA4vEMAofzcISa9KeqxzPyBBEYPZ"
        Alamofire.request(todoEndpoint).responseJSON { (responseData) in
            if let json = responseData.result.value {
                let dic = json as! NSDictionary
                self.arrData = dic.object(forKey: "results") as! NSArray
                self.tbl.reloadData()
                 ActivityIndicator.sharedInstance.setApActivityIndicator(condition: false)
                guard responseData.result.error == nil else {
                    
                    print("error calling GET on /todos/1")
                    print(responseData.result.error!)
                    return
                }
            }}}
    
    func getMostEmailedListApi() {
         ActivityIndicator.sharedInstance.setApActivityIndicator(condition: true)
        let todoEndpoint: String = "https://api.nytimes.com/svc/mostpopular/v2/emailed/7.json?api-key=eaTGTA4vEMAofzcISa9KeqxzPyBBEYPZ"
        Alamofire.request(todoEndpoint).responseJSON { (responseData) in
            if let json = responseData.result.value {
                let dic = json as! NSDictionary
                self.arrData = dic.object(forKey: "results") as! NSArray
                self.tbl.reloadData()
                 ActivityIndicator.sharedInstance.setApActivityIndicator(condition: false)
                guard responseData.result.error == nil else {
                    
                    print("error calling GET on /todos/1")
                    print(responseData.result.error!)
                    return
                }
            }}}
    
    
    func getSearchListApi() {
         ActivityIndicator.sharedInstance.setApActivityIndicator(condition: true)
        
        let todoEndpoint: String = "https://api.nytimes.com/svc/search/v2/articlesearch.json?q=" + (strSearchText as String) + "&api-key=eaTGTA4vEMAofzcISa9KeqxzPyBBEYPZ"
        Alamofire.request(todoEndpoint).responseJSON { (responseData) in
            if let json = responseData.result.value {
                let dic = json as! NSDictionary
                
                let dicsearch = dic.object(forKey: "response") as! NSDictionary
                
                self.arrData = dicsearch.object(forKey: "docs") as! NSArray
                
                if self.arrData.count == 0{
                    
                    let Alert: UIAlertView = UIAlertView(title: "NYT", message: "No record found",
                                                         delegate: self, cancelButtonTitle: "OK")
                    Alert.show()
                }
                else{
                    self.tbl.reloadData()
                     ActivityIndicator.sharedInstance.setApActivityIndicator(condition: false)
                }
                
                
                guard responseData.result.error == nil else {
                    
                    print("error calling GET on /todos/1")
                    print(responseData.result.error!)
                    return
                }
            }}}
    
    
 
 
}
extension ViewedList: UITableViewDataSource, UITableViewDelegate {

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell
    {
      
        let cell = tableView.dequeueReusableCell(withIdentifier: "ViewedCell", for: indexPath as IndexPath) as! ViewedCell
        cell.selectionStyle = .none
        
        var dicDetail = NSDictionary()
        dicDetail = arrData[indexPath.row] as! NSDictionary
       if strIsFrom == "search"{
        
        cell.lblTitle.text = dicDetail.value(forKey: "abstract") as?String
        cell.lblDate.text = (dicDetail.value(forKey: "pub_date") as!String)
        
        }
        
       else{
        
        cell.lblTitle.text = dicDetail.value(forKey: "title") as?String
        cell.lblDate.text = (dicDetail.value(forKey: "published_date") as!String)
        }
        

        
        return cell
        }
 
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat
    {
        
        return UITableView.automaticDimension
        
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
         return self.arrData.count
       
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath)
    {
      
        
    }
    
    
}
