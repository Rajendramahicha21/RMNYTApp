//
//  ActivityIndicator.swift
//  NARI
//
//  Created by mac on 7/19/18.
//  Copyright © 2018 technoBrix. All rights reserved.
//

import UIKit

class ActivityIndicator: UIView {
    var activityIndicator = UIActivityIndicatorView()
    
    class var sharedInstance: ActivityIndicator
    {
        
        struct Static {
            
            static let instance = ActivityIndicator()
            
        }
        return Static.instance
    }
    
    
    func setApActivityIndicator(condition:Bool) {
        
        if condition {
            
            self.alpha = 0.5
            self.backgroundColor = color
            if let window = UIApplication.shared.keyWindow {
                
                window.addSubview(self)
                self.anchor(top: window.topAnchor, leading: window.leadingAnchor, bottom: window.bottomAnchor, trailing: window.trailingAnchor)
                
                
                let transform: CGAffineTransform = CGAffineTransform(scaleX: 1.5, y: 1.5)
                activityIndicator.transform = transform
                self.addSubview(activityIndicator)
                
                activityIndicator.anchor(top:window.centerYAnchor, leading:window.centerXAnchor, bottom:nil, trailing: nil,padding: padding, size: size)
            }
            activityIndicator.startAnimating()
            
            // self.isHidden = false
            
            
        }
        else {
            
            activityIndicator.stopAnimating()
            self.removeFromSuperview()
        }
        
    }
}

extension ActivityIndicator {
    
    var padding:UIEdgeInsets {
        
        get {
            
            return .init(top: -40, left: -40, bottom: 0, right: 0)
        }
    }
    
    var size:CGSize {
        
        get {
            
            return CGSize(width: 80, height: 80)
        }
    }
    var color:UIColor {
        
        get {
            
            return UIColor.black
        }
    }
    
}
extension UIView {
    
    func anchor(top: NSLayoutYAxisAnchor?, leading: NSLayoutXAxisAnchor?, bottom: NSLayoutYAxisAnchor?, trailing: NSLayoutXAxisAnchor?, padding: UIEdgeInsets = .zero, size: CGSize = .zero) {
        translatesAutoresizingMaskIntoConstraints = false
        if let top = top {
            topAnchor.constraint(equalTo: top, constant: padding.top).isActive = true
        }
        
        if let leading = leading {
            leadingAnchor.constraint(equalTo: leading, constant: padding.left).isActive = true
        }
        
        if let bottom = bottom {
            bottomAnchor.constraint(equalTo: bottom, constant: -padding.bottom).isActive = true
        }
        
        if let trailing = trailing {
            trailingAnchor.constraint(equalTo: trailing, constant: -padding.right).isActive = true
        }
        
        if size.width != 0 {
            widthAnchor.constraint(equalToConstant: size.width).isActive = true
        }
        
        if size.height != 0 {
            heightAnchor.constraint(equalToConstant: size.height).isActive = true
        }
    }
}
